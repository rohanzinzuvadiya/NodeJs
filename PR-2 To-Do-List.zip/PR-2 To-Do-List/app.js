const express = require("express");
const app = express();
const port = 1011;

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

let tasks = [
  { id: 1, task: "Learn Node.js" },
  { id: 2, task: "Practice React.js" },
  { id: 3, task: "Complete EJS Project" },
];

app.get("/", (req, res) => {
  res.render("index", { tasks });
});

app.post("/addTask", (req, res) => {
  const newTask = {
    id: tasks.length + 1,
    task: req.body.task,
  };
  tasks.push(newTask);
  res.redirect("/");
});

app.get("/deleteTask", (req, res) => {
  tasks = tasks.filter((task) => task.id != req.query.id);
  res.redirect("/");
});

app.get("/editTask/:id", (req, res) => {
  const task = tasks.find((t) => t.id == req.params.id);
  res.render("edit", { task });
});

app.post("/updateTask", (req, res) => {
  tasks.forEach((t) => {
    if (t.id == req.body.id) {
      t.task = req.body.task;
    }
  });
  res.redirect("/");
});

app.listen(port, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log('Server started at http://localhost:1011');
  }
});
